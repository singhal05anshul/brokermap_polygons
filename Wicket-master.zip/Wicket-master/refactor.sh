java -jar /usr/local/closure/compiler.jar --compilation_level WHITESPACE_ONLY --js wicket-gmap3.src.js --js_output_file wicket-gmap3.js
java -jar /usr/local/closure/compiler.jar --compilation_level WHITESPACE_ONLY --js wicket-leaflet.src.js --js_output_file wicket-leaflet.js
java -jar /usr/local/closure/compiler.jar --compilation_level WHITESPACE_ONLY --js wicket-arcgis.src.js --js_output_file wicket-arcgis.js
java -jar /usr/local/closure/compiler.jar --compilation_level WHITESPACE_ONLY --js wicket.src.js --js_output_file wicket.js
